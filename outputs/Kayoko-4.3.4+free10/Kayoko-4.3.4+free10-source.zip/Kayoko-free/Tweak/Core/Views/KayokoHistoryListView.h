//
//  KayokoHistoryListView.h
//  Kayoko
//
//  Created by Alexandra Aurora Göttlicher
//

#import "KayokoEdgeFadingTableView.h"
#import "KayokoPreferenceKeys.h"

NS_ASSUME_NONNULL_BEGIN

@interface KayokoHistoryListView : KayokoEdgeFadingTableView

@property(nonatomic, copy) NSString *name;
@property(nonatomic, assign) NSUInteger previewLineCount;
@property(nonatomic, assign) KayokoItemDetailsMode itemDetailsMode;
@property(nonatomic, assign) BOOL showIconAndTime;
@property(nonatomic, assign) BOOL showBoldText;
@property(nonatomic, assign) BOOL showApplication;
@property(nonatomic, assign) BOOL showCategory;
@property(nonatomic, assign) BOOL showNote;
@property(nonatomic, assign) BOOL keepsSearchBarVisible;
@property(nonatomic, assign) CGFloat keyboardBottomInset;
@property(nonatomic, assign) CGFloat searchBarSnapHeight;

- (instancetype)initWithName:(NSString *)name;
- (void)setShowsNoSearchResultsPlaceholder:(BOOL)showsNoSearchResultsPlaceholder;
- (void)updateNoSearchResultsPlaceholderLayout;
- (BOOL)isSearchHeaderExposedAtContentOffset:(CGPoint)contentOffset;
- (BOOL)isContentOffsetAtHiddenSearchHeaderBoundary:(CGPoint)contentOffset;
- (void)adjustTargetContentOffsetForSearchBarSnap:(CGPoint *)targetContentOffset;
- (CGFloat)minimumBottomInsetForMaintainingHiddenHeaderWithAdditionalContentHeightReduction:(CGFloat)heightReduction;
- (void)prepareHiddenHeaderInsetsForRemovingRowAtIndexPath:(NSIndexPath *)indexPath;
- (void)beginTransientContentOffsetPreservationAtContentOffset:(CGPoint)contentOffset;
- (void)restoreHiddenSearchHeaderOffsetWithoutAnimation;
- (void)scrollToFirstItemKeepingSearchHeaderHiddenWithoutAnimation;
- (void)scrollToTopAnimated:(BOOL)animated;

@end

NS_ASSUME_NONNULL_END
