#!/bin/sh

export THEOS="$HOME/theos-roothide"
export THEOS_PACKAGE_SCHEME=
export THEOS_DEVICE_IP=
export THEOS_DEVICE_PORT=
export THEOS_DEVICE_SIMULATOR=1
